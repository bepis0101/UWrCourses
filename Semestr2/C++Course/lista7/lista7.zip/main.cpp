#include "gameplay.hpp"
using namespace std;
using namespace game;

int main()
{
    Game game1 = Game();
    game1.gameplay();

    return 0;
}