#pragma once
#include "state.hpp"

namespace bot
{
    pair<uint8_t, uint8_t> move(state::State game);
};