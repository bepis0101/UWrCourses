#include "constant.hpp"
using namespace std;

double pi::evaluate()
{
    return pi;
}
double fi::evaluate()
{
    return fi;
} 
double e::evaluate()
{
    return e;
}
string pi::record()
{
    return "pi";
}
string fi::record()
{
    return "fi";
}
string e::record()
{
    return "e";
}