#ifndef STRUCTS_HPP
#define STRUCTS_HPP
#include <bits/stdc++.h>
#include "punkt.hpp"
struct vec
{
    double x, y; // v = [x, y]
};

struct straight
{
    double a, b; // y = ax + b
};

#endif
